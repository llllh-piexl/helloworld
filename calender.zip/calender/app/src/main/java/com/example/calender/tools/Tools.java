package com.example.calender.tools;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.os.Build;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;

import androidx.annotation.RequiresApi;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Objects;

/**
 * Created by ender on 2021/6/24 12:06
 */
public class Tools {
    /**
     * 设置状态栏全透明
     *
     * @param activity 需要设置的activity
     */
    @SuppressLint("ObsoleteSdkInt")
    public static void setTransparent(Activity activity) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.KITKAT) {
            return;
        }
        transparentStatusBar(activity);
    }

    /**
     * 使状态栏透明
     */
    @TargetApi(Build.VERSION_CODES.KITKAT)
    private static void transparentStatusBar(Activity activity) {
        activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        activity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        //需要设置这个flag contentView才能延伸到状态栏
        activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
        //状态栏覆盖在contentView上面，设置透明使contentView的背景透出来
        activity.getWindow().setStatusBarColor(Color.TRANSPARENT);
    }

    /**
     * 修改状态栏字体颜色
     */
    @RequiresApi(api = Build.VERSION_CODES.M)
    public static void setAndroidNativeLightStatusBar(Activity activity, boolean dark) {
        View decor = activity.getWindow().getDecorView();
        if (dark) {
            decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        } else {
            decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
    }

    /**
     * 获取今天的日期 yyyy-MM-dd
     *
     * @return yyyy-MM-dd
     */
    public static String getTodayDate() {
        //获取今天日期
        @SuppressLint("SimpleDateFormat")
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        Date today = new Date();
        return formatter.format(today);
    }
    /**
     * 通过状态栏资源id来获取状态栏高度
     *
     * @param context 上下文
     */
    public static int getStatusBarByResId(Context context) {
        int height = 0;
        // 获取状态栏资源id
        int resourceId = context.getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (resourceId > 0) {
            try {
                height = context.getResources().getDimensionPixelSize(resourceId);
            } catch (Exception e) {
                Log.e("获取状态栏高度", "getStatusBarByResId: ", e);
            }
        }
        return height;
    }

    /**

     * 根据日期获取当天是周几

     * @param datetime 日期

     * @return 周几

     */

    public static String dateToWeek(String datetime) {
        @SuppressLint("SimpleDateFormat")
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

        String[] weekDays = {"星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"};

        Calendar cal = Calendar.getInstance();

        Date date;

        try {
            date = sdf.parse(datetime);

            cal.setTime(Objects.requireNonNull(date));

        } catch (ParseException e) {
            e.printStackTrace();

        }

        int w = cal.get(Calendar.DAY_OF_WEEK) - 1;

        return weekDays[w];

    }

    /**
     * 建个节假日信息库
     *
     * @param holidayName 节假日名字
     *
     * @return position 0 习俗   1  相关古诗词或文化来源
     * */
    public static List<String> getHolidayData(String holidayName){
        List<String> holidayDataList = new ArrayList<>();

        switch (holidayName){
            case "端午节":
                holidayDataList.add("集拜神祭祖、祈福辟邪、欢庆娱乐和饮食为一体的民俗大节");
                holidayDataList.add("《端午日》"+"\n"+ "殷尧藩 〔唐代〕"+ "\n"+"少年佳节倍多情"+"\n"+"老去谁知感慨生"+"\n"+"不效艾符趋习俗"+"\n"+"但祈蒲酒话升平"+"\n"+"鬓丝日日添头白"+"\n"+"榴锦年年照眼明"+"\n"+"千载贤愚同瞬息"+"\n"+"几人湮没几垂名");
                break;
            case "青年节":
                holidayDataList.add("源于中国1919年反帝爱国的“五四运动”");
                holidayDataList.add("青年节期间，中国各地都要举行丰富多彩的纪念活动，青年们还要集中进行各种社会志愿和社会实践活动，还有许多地方在青年节期间举行成人仪式。");
                break;
            case "元旦":
                holidayDataList.add("是世界多数国家通称的“新年”。元，谓“始”，凡数之始称为“元”；旦，谓“日”；“元旦”即“初始之日”的意思");
                holidayDataList.add("现代中国的元旦，根据中国政府将其列入法定假日，成为全国人民的节日。放假一天，后常常将当日前或后双休日调整，一般连续休息三天。现代中国对元旦的庆祝较之春节，重要性要小得多。一般机关、企业会举行年终集体庆祝活动，但民间活动很少。");
                break;
            case "腊八节":
                holidayDataList.add("又称为“法宝节”“佛成道节”“成道会”等。本为佛教纪念释迦牟尼佛成道之节日，后逐渐也成为民间节日");
                holidayDataList.add("”我国喝腊八粥的历史，已有一千年以上了。每逢腊八这天，不论是朝廷官府、寺院还是黎民百姓家都要做腊八粥。到了清朝，喝腊八粥的风俗更是盛行");
                break;
            case "除夕":
                holidayDataList.add("为岁末的最后一天夜晚。岁末的最后一天称为“岁除”，意为旧岁至此而除，另换新岁");
                holidayDataList.add("是除旧布新、阖家团圆、祭祀祖先的日子");
                break;
            case "春节":
                holidayDataList.add("即中国农历新年，俗称新春、新岁、岁旦等，口头上又称过年、过大年。春节历史悠久，由上古时代岁首祈岁祭祀演变而来");
                holidayDataList.add("在春节期间，全国各地均有举行各种庆贺新春活动，带有浓郁的各地域特色。这些活动以除旧布新、驱邪攘灾、拜神祭祖、纳福祈年为主要内容，形式丰富多彩，凝聚着中华传统文化精华");
                break;
            case "情人节":
                holidayDataList.add("又称圣瓦伦丁节或圣华伦泰节，日期在每年公历的2月14日，是西方国家的传统节日之一，起源于基督教。如今已经成为全世界著名的浪漫节日，但是不同国家的人们表达爱意的方式却各不相同");
                holidayDataList.add("情人节是一个关于爱、浪漫以及花、巧克力、贺卡的节日，男女在这一天互送礼物用以表达爱意或友好。情人节的晚餐约会通常代表了情侣关系的发展关键");
                break;
            case "元宵节":
                holidayDataList.add("中国的传统节日之一，又称上元节、小正月、元夕或灯节");
                holidayDataList.add("元宵节主要有赏花灯、吃汤圆、猜灯谜、放烟花等一系列传统民俗活动。此外，不少地方元宵节还增加了游龙灯、舞狮子、踩高跷、划旱船、扭秧歌、打太平鼓等传统民俗表演");
                break;
            case "妇女节":
                holidayDataList.add("又被称为“国际妇女节”、“三八节”和“三八妇女节”。是在每年的3月8日为庆祝妇女在经济、政治和社会等领域作出的重要贡献和取得的巨大成就而设立的节日");
                holidayDataList.add("这一天，妇女们作出的成就得到肯定，无论她们的国籍、民族、语言、文化、经济状况和政治立场如何。自设立之初，国际妇女节为发达国家及发展中国家的妇女开启了一个新天地。日益发展壮大的国际妇女运动，通过联合国四次妇女问题全球会议得以加强，国际妇女节纪念活动已成为一个争取妇女权利和妇女对政治经济事务的参与的集结令");
                break;
            case "植树节":
                holidayDataList.add("提倡通过这种活动，激发人们爱林造林的热情、意识到环保的重要性");
                holidayDataList.add("中国的植树节由凌道扬和韩安、裴义理等林学家于1915年倡议设立，最初将时间确定在每年清明节。1928年，国民政府为纪念孙中山逝世三周年将植树节改为3月12日。新中国成立后的1979年，在邓小平提议下，第五届全国人大常委会第六次会议决定将每年的3月12日定为植树节");
                break;
            case "龙抬头":
                holidayDataList.add("又称春耕节、农事节、青龙节、春龙节等，是中国民间传统节日");
                holidayDataList.add("“龙角星”就从东方地平线上升起，故称“龙抬头”。龙抬头日在仲春卯月初，“卯”五行属木，卦象为“震”；九二在临卦互震里，表示龙离开了潜伏的状态，已出现于地表上，崭露头角，为生发之大象");
                break;
            case "消费者":
                holidayDataList.add("由国际消费者联盟组织于1983年确定，目的在于扩大消费者权益保护的宣传，使消费者权益在世界范围内得到重视，以促进各国和地区消费者组织之间的合作与交往，在国际范围内更好地保护消费者权益。");
                holidayDataList.add("2021年国际消费者权益日的主题是“守护安全 畅通消费”");
                break;
            case "愚人节":
                holidayDataList.add("也称万愚节、幽默节。愚人节，时间为4月1日，是从19世纪开始在西方兴起流行的民间节日，并未被任何国家认定为法定节日");
                holidayDataList.add("在这一天人们以各种方式互相欺骗和捉弄，往往在玩笑的最后才揭穿并宣告捉弄对象为“愚人”。玩笑的性质极少包含实质恶意，但个别玩笑由于开得过大而引起人们的恐慌，从而产生较大规模反响并且衍生成为（传媒）谣言和都市传说，所以对于人们来说一般会加以避免开如有关灾难之事的玩笑");
                break;
            case "清明节":
                holidayDataList.add("又称踏青节、行清节、三月节、祭祖节等，节期在仲春与暮春之交");
                holidayDataList.add("扫墓祭祖与踏青郊游是清明节的两大礼俗主题，这两大传统礼俗主题在中国自古传承，至今不辍");
                break;
            case "劳动节":
                holidayDataList.add("又称“五一国际劳动节”“国际示威游行日”");
                holidayDataList.add("是全世界劳动人民共同拥有的节日");
                break;
            case "儿童节":
                holidayDataList.add("为了悼念1942年6月10日的利迪策惨案和全世界所有在战争中死难的儿童，反对虐杀和毒害儿童，以及保障儿童权利");
                holidayDataList.add("世界上许多国家都将6月1日定为儿童的节日");
                break;
            case "建党节":
                holidayDataList.add("毛泽东同志于1938年5月提出来的");
                holidayDataList.add("毛泽东在《论持久战》一文中提出：“今年七月一日，是中国共产党建立的十七周年纪念日”。这是中央领导同志第一次明确提出“七一”是党的诞生纪念日");
                break;
            case "建军节":
                holidayDataList.add("是中国人民解放军建军纪念日，定为每年的八月一日，由中国人民革命军事委员会设立，为纪念中国工农红军成立的节日");
                holidayDataList.add("1933年7月11日，中华苏维埃共和国临时中央政府根据中央革命军事委员会6月30日的建议，决定8月1日为中国工农红军成立纪念日。1949年6月15日，中国人民革命军事委员会发布命令，以“八一”两字作为中国人民解放军军旗和军徽的主要标志。中华人民共和国成立后，将此纪念日改称为中国人民解放军建军节");
                break;
            case "七夕节":
                holidayDataList.add("又称七巧节、七姐节、女儿节、乞巧节、七娘会、七夕祭、牛公牛婆日、巧夕等");
                holidayDataList.add("以“牛郎织女”民间传说为载体，以祈福、乞巧、爱情为主题，以女性为主体的综合性节日");
                break;
            case "中元节":
                holidayDataList.add("是道教名称，民间世俗称为七月半、七月十四（另一说七月十五 [1]  ）祭祖节，佛教称为盂兰盆节。节日习俗主要有祭祖、放河灯、祀亡魂、焚纸锭、祭祀土地");
                holidayDataList.add("它的产生可追溯到上古时代的祖灵崇拜以及相关时祭。七月乃吉祥月、孝亲月，七月半是民间初秋庆贺丰收、酬谢大地的节日，有若干农作物成熟，民间按例要祀祖，用新稻米等祭供，向祖先报告秋成。该节是追怀先人的一种文化传统节日，其文化核心是敬祖尽孝");
                break;
            case "教师节":
                holidayDataList.add("教师节，旨在肯定教师为教育事业所做的贡献");
                holidayDataList.add("在中国近现代史上，多次以不同的日期作为过教师节。直至1985年，第六届全国人大常委会第九次会议通过了国务院关于建立教师节的议案，才真正确定了1985年9月10日为中国第一个教师节");
                break;
            case "中秋节":
                holidayDataList.add("又称祭月节、月光诞、月夕、秋节、仲秋节、拜月节、月娘节、月亮节、团圆节等");
                holidayDataList.add("中秋节与春节、清明节、端午节并称为中国四大传统节日。受中华文化的影响，中秋节也是东亚和东南亚一些国家尤其是当地的华人华侨的传统节日。2006年5月20日，国务院将其列入首批国家级非物质文化遗产名录。自2008年起中秋节被列为国家法定节假日");
                break;
            case "国庆节":
                holidayDataList.add("通常是这个国家的独立、宪法的签署、元首诞辰或其他有重大纪念意义的周年纪念日；也有些是这个国家守护神的圣人节");
                holidayDataList.add("“国庆”一词，本指国家喜庆之事，最早见于西晋。西晋的文学家陆机在《五等诸侯论》一文中就曾有“国庆独飨其利，主忧莫与其害”的记载、我国封建时代、国家喜庆的大事，莫大过于帝王的登基、诞辰等。因而我国古代把皇帝即位、诞辰称为“国庆”。今天称国家建立的纪念日为国庆节");
                break;
            case "重阳节":
                holidayDataList.add("重阳节，是中国传统节日，节期为每年农历九月初九");
                holidayDataList.add("“九”数在《易经》中为阳数，“九九”两阳数相重，故曰“重阳”；因日与月皆逢九，故又称为“重九”。九九归真，一元肇始，古人认为九九重阳是吉祥的日子。古时民间在重阳节有登高祈福、秋游赏菊、佩插茱萸、拜神祭祖及饮宴祈寿等习俗。传承至今，又添加了敬老等内涵，于重阳之日享宴高会，感恩敬老。登高赏秋与感恩敬老是当今重阳节日活动的两大重要主题");
                break;
            default:
                break;
        }
        return holidayDataList;
    }

}
