package com.example.calender;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;

import com.example.calender.databinding.ActivityMainBinding;
import com.example.calender.tools.Tools;
import com.necer.calendar.BaseCalendar;
import com.necer.calendar.Miui10Calendar;
import com.necer.entity.CalendarDate;
import com.necer.enumeration.DateChangeBehavior;
import com.necer.listener.OnCalendarChangedListener;
import com.necer.utils.CalendarUtil;

import org.joda.time.LocalDate;

import java.util.List;

import static com.example.calender.tools.Tools.getStatusBarByResId;

public class MainActivity extends AppCompatActivity {

    /**
     * 视图绑定类
     * */
    private ActivityMainBinding binding;

    /**
     * 日历数据类
     * */
    private CalendarDate calendarDate;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        super.onCreate(savedInstanceState);
        setContentView(binding.getRoot());

        //沉浸式状态栏
        Tools.setTransparent(this);
        // 设置状态栏字体为黑色
        Tools.setAndroidNativeLightStatusBar(this, true);
        //初始化日历
        initCalender();
        setTop();
    }

    /**
     *初始化日历
     * */
    private void initCalender() {
        Miui10Calendar calendar = binding.activityMainCalender;
        calendar.setStretchCalendarEnable(true);
        calendar.setWeekHoldEnable(false);
        calendar.setOnCalendarChangedListener(new OnCalendarChangedListener() {
            @Override
            public void onCalendarChange(BaseCalendar baseCalendar, int year, int month, LocalDate localDate, DateChangeBehavior dateChangeBehavior) {
                CalendarDate calendarDate = CalendarUtil.getCalendarDate(localDate);
                List<String> holidayDataList;
      
                if (calendarDate.lunarHoliday.length()>0){
                    holidayDataList = Tools.getHolidayData(calendarDate.lunarHoliday);
                    binding.activityMainTextHolidayName.setText(calendarDate.lunarHoliday);
                    binding.activityMainTextFolk.setText(holidayDataList.get(0));
                    binding.activityMainTextPoetry.setText(holidayDataList.get(1));
                    binding.activityMainViewHoliday.setVisibility(View.VISIBLE);
                }else if (calendarDate.solarHoliday.length()>0){
                    holidayDataList = Tools.getHolidayData(calendarDate.solarHoliday);
                    binding.activityMainTextHolidayName.setText(calendarDate.solarHoliday);
                    binding.activityMainTextFolk.setText(holidayDataList.get(0));
                    binding.activityMainTextPoetry.setText(holidayDataList.get(1));
                    binding.activityMainViewHoliday.setVisibility(View.VISIBLE);
                }else{
                    binding.activityMainViewHoliday.setVisibility(View.INVISIBLE);
                }
                binding.activityMainTextLateDate.setText("农历"+calendarDate.lunar.lunarMonthStr+calendarDate.lunar.lunarDayStr);
                binding.activityMainTextDetails.setText(calendarDate.lunar.lunarYearStr+"年");
                binding.activityMainTextTitleDate.setText(year+"年"+month+"月");
                binding.activityMainTextIntervalDays.setText(Tools.dateToWeek(localDate.toString()));
            }
        });

    }


    private void setTop(){
        ConstraintLayout.LayoutParams lp = (ConstraintLayout.LayoutParams) binding.activityMainToolbarView.getLayoutParams();
        lp.topMargin = getStatusBarByResId(this);
        binding.activityMainToolbarView.setLayoutParams(lp);
    }
}